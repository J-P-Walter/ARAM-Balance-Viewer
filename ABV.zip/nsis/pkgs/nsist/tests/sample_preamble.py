os.environ['NSIST_TEST_PREAMBLE'] = '1'
